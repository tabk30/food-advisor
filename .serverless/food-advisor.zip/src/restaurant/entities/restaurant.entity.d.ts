export declare class OpeningHours {
    day_interval: string;
    opening_hour: string;
    closing_hour: string;
}
export declare class Location {
    address: string;
    website: string;
    phone: string;
}
export declare class Restaurant {
    id: number;
    name: string;
    images?: string[];
    slug?: string;
    price: number;
    description?: string;
    opening_hours?: OpeningHours[];
    location?: Location;
    created_at: Date;
    updated_at?: Date;
    deleted_at?: Date;
}
