"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateRestaurantDto = void 0;
class CreateRestaurantDto {
}
exports.CreateRestaurantDto = CreateRestaurantDto;
//# sourceMappingURL=create-restaurant.dto.js.map