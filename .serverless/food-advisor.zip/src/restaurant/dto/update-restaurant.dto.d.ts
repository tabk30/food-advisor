import { CreateRestaurantDto } from './create-restaurant.dto';
declare const UpdateRestaurantDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateRestaurantDto>>;
export declare class UpdateRestaurantDto extends UpdateRestaurantDto_base {
}
export {};
