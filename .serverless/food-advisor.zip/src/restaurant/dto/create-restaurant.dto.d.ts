export declare class CreateRestaurantDto {
}
