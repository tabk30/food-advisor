export declare class RestaurantModule {
}
